package com.triple.dreamlib.dto;

public class MaxBookIdDto {

	private String  book_id; 

	public MaxBookIdDto() {
	}
			
	public MaxBookIdDto(String book_id) {
		this.book_id = book_id;
	}

	public String getBook_id() {
		return book_id;
	}

	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	
}
